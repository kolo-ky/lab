module.exports = {
  resolve: {
    alias: {
      '@': require('path').resolve(__dirname, 'src'), // change this to your folder path
    },
  },
};
