<template>
  <section class="work-area work-area--report">
    <ul class="report-area">
      <li class="report-area__header">
        <h2 class="report-area__header-title">Динамика постов по сетям</h2>
        <span class="report-area__header-subtitle">По часам</span>
      </li>
      <li class="report-area__report">
        <dynamic-chart-hour></dynamic-chart-hour>
      </li>
    </ul>

    <ul class="report-area">
      <li class="report-area__header">
        <h2 class="report-area__header-title">Динамика тональности</h2>
        <span class="report-area__header-subtitle">По часам</span>
      </li>
      <li class="report-area__report">
        <tonal-dynamics></tonal-dynamics>
      </li>
    </ul>
  </section>
</template>

<script>
import DynamicChartHour from '@/components/graphics/DynamicChartHour.vue';
import TonalDynamics from '@/components/graphics/TonalDynamics.vue';

import { getAdditionalInfoApi } from '@/api/posts';

export default {
  name: 'Reports',
  data() {
    return {};
  },
  mounted() {
    this.getAdditionalInfo(this.$route.params.id);
  },
  methods: {
    getAdditionalInfo(id) {
      const params = {
        thread_id: id,
      };
      getAdditionalInfoApi(params)
        .then((resp) => {
          this.dataForChart = resp.data.publicationsgrowthwithtrust;
        })
        .catch(err => err);
    },
  },
  components: {
    DynamicChartHour,
    TonalDynamics,
  },
};
</script>

<style>
  .work-area--report {
    padding-top: 25px;
  }

  .report-area {
    padding: 20px 45px;
    margin: 0 0 30px 0;
    width: 100%;
    background-color: #ffffff;
    border-radius: 4px;
    list-style: none;
  }

  .report-area__header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .report-area__header-title {
    font-weight: normal;
    line-height: 24px;
    font-size: 18px;
  }

  .report-area__header-subtitle {
    padding: 6px 9px;
    background: #eeeeee;
    border-radius: 4px;
  }
</style>
