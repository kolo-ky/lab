<template lang="pug">
  .work-area
    template(v-if="!$route.params.id")
      router-link(to="/").go-back < К списку лент
      #map.main-container
    template(v-else)
      router-link(to="/map").go-back < К карте
      posts(v-if="$route.params.id")
</template>

<script>
import Posts from '@/components/posts/index.vue';

export default {
  name: 'Map',
  components: { Posts },
  methods: {
    yandexMapInti() {
      ymaps.ready(init);
      function init() {
        // Создание карты.
        const myMap = new ymaps.Map('map', {
          // Координаты центра карты.
          // Порядок по умолчанию: «широта, долгота».
          // Чтобы не определять координаты центра карты вручную,
          // воспользуйтесь инструментом Определение координат.
          center: [59.930502, 30.3283223],
          // Уровень масштабирования. Допустимые значения:
          // от 0 (весь мир) до 19.
          zoom: 10,
        });
        const myGeoObject = new ymaps.GeoObject({
          geometry: {
            type: 'Point', // тип геометрии - точка
            coordinates: [59.8775052, 30.3336003], // координаты точки
          },
          properties: {
            locationUrl: '/thread-id-1003',
            iconCaption: 'Прорыв трубы на Сызранской (Московский район)',
          },
        });
        myMap.geoObjects.add(myGeoObject);
        const myGeoObject2 = new ymaps.GeoObject({
          geometry: {
            type: 'Point', // тип геометрии - точка
            coordinates: [59.9157046, 30.3244763], // координаты точки
          },
          properties: {
            locationUrl: '/thread-id-1005',
            iconCaption: 'Прорыв трубы (Адмиралтейский район)',
          },
          hintContent: 'Прорыв трубы (Адмиралтейский район)',
        });
        myMap.geoObjects.add(myGeoObject2);
        const myGeoObject3 = new ymaps.GeoObject({
          geometry: {
            type: 'Point', // тип геометрии - точка
            coordinates: [59.8630147, 30.1675354], // координаты точки
          },
          properties: {
            locationUrl: '/thread-id-1006',
            iconCaption: 'Взрыв в типографии (Кировский район)',
          },
        });
        myMap.geoObjects.add(myGeoObject3);
        myMap.geoObjects.events.add('click', (e) => {
          // Объект на котором произошло событие
          const target = e.get('target');
          window.location.href = target.properties.get('locationUrl');
        });
      }
    },
  },
  mounted() {
    this.yandexMapInti();
  },
  watch: {
    $route() {
      if (!this.$route.params.id) {
        this.yandexMapInti();
      }
    },
  },
};
</script>

<style lang="stylus">
#map
  flex-grow 1
.go-back
  margin 1em
  font-size 1.4em
  text-decoration none
  color #3a3a3a
  &:hover
    text-decoration underline
</style>
