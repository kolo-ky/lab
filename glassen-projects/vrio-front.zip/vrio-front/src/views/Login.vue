<template lang="pug">
  .work-area
    form.login-form(@submit.prevent='loginAction()')
      .login-form__ttl Вход в систему
      input.login-form__input(v-model="login" placeholder="Login")
      input.login-form__input(v-model="password" placeholder="Password" type="password")
      button(type='submit').login-form__btn Войти
</template>

<script>
import { AUTH_REQUEST } from '@/store/actions/auth';

export default {
  name: 'Login',
  data() {
    return {
      login: '',
      password: '',
    };
  },
  methods: {
    loginAction() {
      const loginParams = {
        login: this.login,
        password: this.password,
      };
      this.$store.dispatch(AUTH_REQUEST, loginParams).then(() => this.$router.push('/'));
    },
  },
};
</script>

<style lang="stylus">
.login-form
  position absolute
  left 50%
  top 50%
  transform translate(-50%, -50%)
  display flex
  flex-direction column
  align-items center
  border-radius 4px
  border 1px solid #3a3a3a
  padding 2em 4em
  background #fff
  &__input
    margin 1em 0
    padding 0 0 0 1em
    line-height 3em
    box-shadow none
    outline none
    border none
    border-radius 4px
    max-width 100%
    background #edeef0
  &__btn
    line-height 2.4em
    border-radius 4px
    border 1px solid #3a3a3a
    padding 0 1.2em
    cursor pointer
    margin 1em
    &:hover
      background #fff
</style>
