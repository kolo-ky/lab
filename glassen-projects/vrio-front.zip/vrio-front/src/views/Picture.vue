<template>
  <div>
    Picture is work!
  </div>
</template>

<script>
export default {
  name: 'Picture',
};
</script>

<style>
</style>
