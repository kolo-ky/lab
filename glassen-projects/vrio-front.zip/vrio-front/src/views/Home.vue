<template lang="pug">
  .work-area
    //header-main
    //info-panel
    posts(v-if="$route.params.id")
</template>

<script>
import Posts from '@/components/posts/index.vue';
import HeaderMain from '@/components/header/index.vue';
import InfoPanel from '@/components/infoPanel/index.vue';

export default {
  name: 'Home',
  components: { InfoPanel, HeaderMain, Posts },
};
</script>

<style lang="stylus">
.result-empty
  text-align center
  font-size 1.6em
  margin-top 3em
</style>
