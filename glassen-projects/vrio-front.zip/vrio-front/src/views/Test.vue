<template lang="pug">
  .work-area(v-bar)
    div.thread(@scroll="test")
      post.main-container(v-for="post in items" :post="post")
      table-preloader(v-if="reqPending" style="margin-top: 4em")
</template>

<script>
import Post from '@/components/posts/post.vue';
import { getPostsApi } from '@/api/posts';
import TablePreloader from '@/components/preLoaders/tablePreloader.vue';

export default {
  name: 'Test',
  components: { TablePreloader, Post },
  data() {
    return {
      items: [],
      reqPending: false,
      count: '',
      start: 0,
    };
  },
  methods: {
    test($event) {
      const element = $event.target;
      if (element.scrollHeight - element.scrollTop === element.clientHeight) {
        if (this.items.length + 1 < this.count) {
          this.getPosts(this.$route.params.id);
        }
      }
    },
    getPosts(id) {
      this.reqPending = true;
      const params = {
        thread_id: id,
        limit: 20,
        start: this.start,
        sort: {
          type: 'date',
          order: 'desc',
        },
      };
      getPostsApi(params)
        .then((req) => {
          this.items = this.items.concat(req.data.posts);
          this.reqPending = false;
          this.count = req.data.count;
          this.start += this.start;
        });
    },
    getHeight() {
      const headerHeight = window.document.querySelector('.header').offsetHeight;
      document.querySelector('.wrapper').style.height = `${document.body.offsetHeight - headerHeight - document.querySelector('.work-area').style.marginTop - document.querySelector('.work-area').style.marginBottom}px`;
    },
  },
  mounted() {
    this.items = [];
    this.count = '';
    // this.getHeight();
    this.getPosts(this.$route.params.id);
  },
  watch: {
    $route() {
      this.items = [];
      this.getPosts(this.$route.params.id);
    },
  },
};
</script>

<style lang="stylus">
.thread
  padding 1em
</style>
