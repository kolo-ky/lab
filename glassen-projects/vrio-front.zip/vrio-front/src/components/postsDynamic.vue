<template lang="pug">
  .posts-dynamic
    .posts-dynamic__ttl Динамика постов
    bar(
      :chart-data="datacollection"
      :options="options"
      :width="300"
      :height="160"
      v-if="datacollection"
    )
</template>

<script>
import Bar from './postsDynamicChart';
import { getAdditionalInfoApi } from '@/api/posts';

export default {
  name: 'postsDynamic',
  components: { Bar },
  data() {
    return {
      dataForChart: '',
      datacollection: '',
      options: {
        barValueSpacing: 0,
        scales: {
          xAxes: [{
            stacked: true,
            gridLines: {
              color: 'rgba(0, 0, 0, 0)',
            },
          }],
          yAxes: [{
            stacked: true,
            gridLines: {
              color: 'rgba(0, 0, 0, 0)',
            },
            ticks: {
              display: false,
              suggestedMax: 20,
            },
          }],
        },
        legend: {
          display: false,
        },
        tooltips: {
          callbacks: {
            label(tooltipItem) {
              return tooltipItem.yLabel;
            },
          },
        },
        plugins: {
          datalabels: {
            formatter: (value, ctx) => {
              if (ctx.chart.data.datasets.length) {
                const datasets = ctx.chart.data.datasets.filter((ds) => {
                  if (ds._meta[0]) {
                    return !ds._meta[0].hidden;
                  }
                  return true;
                });
                if (datasets.indexOf(ctx.dataset) === datasets.length - 1) {
                  let sum = 0;
                  datasets.map((dataset) => {
                    sum += dataset.data[ctx.dataIndex];
                  });
                  return sum;
                }
              }
              return '';
            },
            anchor: 'end',
            align: 'end',
          },
        },
      },
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.getAdditionalInfo(this.$route.params.id);
    });
  },
  watch: {
    $route() {
      this.getAdditionalInfo(this.$route.params.id);
    },
  },
  methods: {
    getAdditionalInfo(id) {
      const params = {
        thread_id: id,
      };
      getAdditionalInfoApi(params)
        .then((resp) => {
          this.dataForChart = resp.data.publicationsgrowthwithtrust;
          this.datacollection = {
            labels: this.dataForChart.negative.map(elem => elem[0]),
            datasets: [{
              label: 'neutral',
              backgroundColor: '#c4c4c4',
              data: this.dataForChart.netural.map(elem => elem[1]),
            }, {
              label: 'negative',
              backgroundColor: '#ED002B',
              data: this.dataForChart.negative.map(elem => elem[1]),
            }, {
              label: 'positive',
              backgroundColor: '#03bb9a',
              data: this.dataForChart.positive.map(elem => elem[1]),
            }],
          };
        })
        .catch(err => err);
    },
  },
};
</script>

<style lang="stylus">
.posts-dynamic
  height 200px
  background #fff
  padding 1em
  margin-bottom 20px
  border-radius 4px
  &__ttl
    font-size 1.5em
</style>
