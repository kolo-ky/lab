<template lang="pug">
  .info-panel-counts
    table-preloader.info-panel-counts__preloader(v-if="requestPending")
    template(
      v-if="!requestPending"
    )
      .info-panel-counts__stats(v-if="weekTrust.poststats")
        .info-panel-counts__item
          img.info-panel-counts__item-icon(src="../../assets/images/icon-posts-count.svg")
          .info-panel-counts__item-ttl Посты:
          .info-panel-counts__item-value {{ weekTrust.total }}
        .info-panel-counts__item
          img.info-panel-counts__item-icon(src="../../assets/images/icon-like.svg")
          .info-panel-counts__item-ttl Лайки:
          .info-panel-counts__item-value {{ weekTrust.poststats.likes }}
        .info-panel-counts__item
          img.info-panel-counts__item-icon(src="../../assets/images/icon-repost.svg")
          .info-panel-counts__item-ttl Репосты:
          .info-panel-counts__item-value {{ weekTrust.poststats.reposts }}
      .info-panel-counts__trust(
        v-if="weekTrust.trust"
      )
        .info-panel-counts__item(
          style="color: #03bb9a"
          v-if="weekTrust.trust"
        )
          img.info-panel-counts__item-icon(src="../../assets/images/icon-feeds-positive.svg")
          .info-panel-counts__item-value {{ weekTrust.trust[0].positive }}
        .info-panel-counts__item(
          style="color: #3c3c3c"
          v-if="weekTrust.trust.length"
        )
          img.info-panel-counts__item-icon(src="../../assets/images/neutral.svg")
          .info-panel-counts__item-value {{ weekTrust.trust[0].netural }}
        .info-panel-counts__item(
          style="color: #ed002b"
          v-if="weekTrust.trust.length"
        )
          img.info-panel-counts__item-icon(src="../../assets/images/icon-feeds-negative.svg")
          .info-panel-counts__item-value {{ weekTrust.trust[0].negative }}
      span(v-if="!weekTrust") Статистика в процессе сбора
</template>

<script>
import { getWeekTrustApi } from '@/api/posts';
import TablePreloader from '@/components/preLoaders/tablePreloader.vue';

export default {
  name: 'infoPanelCounts',
  components: { TablePreloader },
  data() {
    return {
      weekTrust: false,
      requestPending: false,
    };
  },
  mounted() {
    if (this.$route.params.id) {
      this.getWeekTrust(this.$route.params.id);
    }
  },
  methods: {
    getWeekTrust(id) {
      this.requestPending = true;
      const params = {
        thread_id: id,
      };
      getWeekTrustApi(params)
        .then((resp) => {
          this.weekTrust = resp.data;
          this.requestPending = false;
        })
        .catch((err) => {
          this.requestPending = false;
          return err;
        });
    },
  },
  watch: {
    $route() {
      this.getWeekTrust(this.$route.params.id);
    },
  },
};
</script>

<style lang="stylus">
.info-panel-counts
  display flex
  align-items center
  padding 2em 0 1em
  &__item
    display flex
    align-items center
    margin-right 1.5em
    margin-bottom 1em
    &-ttl
      margin-right .4em
    &-icon
      margin-right .5em
      width 16px
      height 16px
    &-value
      font-weight bold
  &__trust
    display flex
    flex-direction column
    margin-right auto
  &__stats
    display flex
    flex-direction column
    margin-right 2em
    margin-left auto
</style>
