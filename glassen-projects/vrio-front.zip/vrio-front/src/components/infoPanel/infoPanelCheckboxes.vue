<template lang="pug">
  .info-panel-checkboxes
    .info-panel-checkboxes__item
      input.info-panel-checkboxes__item-input(
        name="postsType"
        type="checkbox"
        value="smi"
        v-model="postsType"
      )
      img.info-panel-checkboxes__item-icon(
        src="../../assets/images/icon-checkbox.svg"
        v-if="postsType.includes('smi')"
      )
      img.info-panel-checkboxes__item-icon(
        src="../../assets/images/icon-checkbox-unchecked.svg"
        v-else
      )
      .info-panel-checkboxes__item-ttl СМИ
    .info-panel-checkboxes__item
      input.info-panel-checkboxes__item-input(
        name="postsType"
        type="checkbox"
        value="soc"
        v-model="postsType"
      )
      img.info-panel-checkboxes__item-icon(
        src="../../assets/images/icon-checkbox.svg"
        v-if="postsType.includes('soc')"
      )
      img.info-panel-checkboxes__item-icon(
        src="../../assets/images/icon-checkbox-unchecked.svg"
        v-else
      )
      .info-panel-checkboxes__item-ttl Соц. сети
</template>

<script>
import { POST_TYPE_TO_SHOW } from '@/store/actions/posts';

export default {
  name: 'infoPanelCheckboxes',
  data() {
    return {
      postsType: ['smi', 'soc'],
    };
  },
  mounted() {
    this.$store.dispatch(POST_TYPE_TO_SHOW, this.postsType);
  },
  watch: {
    postsType(val) {
      this.$store.dispatch(POST_TYPE_TO_SHOW, val);
    },
  },
};
</script>

<style lang="stylus">
.info-panel-checkboxes
  display flex
  align-items center
  margin 0 .4em 0 auto
  border-left 1px solid #eee
  &__item
    display flex
    align-items center
    position relative
    &-input
      position absolute
      left 0
      top 0
      width 100%
      height 100%
      opacity 0
      cursor pointer
    &-icon
      margin 0 .5em 0 1em
    &-ttl
      text-transform uppercase
</style>
