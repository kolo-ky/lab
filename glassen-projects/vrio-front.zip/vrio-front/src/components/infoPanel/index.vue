<template lang="pug">
  .info-panel
    show-menu-btn
    info-panel-counts
    info-panel-checkboxes
    user-menu
    <!--router-link.info-panel__map-link(to="/map") Тепловая карта-->
</template>

<script>
import InfoPanelCounts from '@/components/infoPanel/infoPanelCounts.vue';
import InfoPanelCheckboxes from '@/components/infoPanel/infoPanelCheckboxes.vue';
import UserMenu from '@/components/header/userMenu.vue';
import ShowMenuBtn from '@/components/header/showMenuBtn.vue';

export default {
  name: 'infoPanel',
  components: {
    ShowMenuBtn,
    UserMenu,
    InfoPanelCheckboxes,
    InfoPanelCounts,
  },
};
</script>

<style lang="stylus">
.info-panel
  display flex
  align-items center
  padding 0 0 0 2em
  background #fff
  margin 2em 1.4em 1em .4em
  border-radius 4px
  flex-shrink 0
  &__map-link
    text-decoration none
    padding-left 1em
    border-left 1px solid #eee
    align-self stretch
</style>
