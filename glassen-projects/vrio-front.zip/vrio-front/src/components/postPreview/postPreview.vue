<template lang="pug">
  .post-preview-container(v-if="posts.length")
    template(v-for="(post, index) in posts")
      .post-preview.main-container(@click="showFullInfo(post, index)")
        post-preview-header(:post="post")
        post-preview-body(:post="post")
        .post__date
          img.post__source-icon(:src="sourceIcon(post.network_name)")
          span {{ moment(post.created_date).format('HH:mm DD.MM.YYYY') }}
      .post-more-container(
        v-if="!((index + 1) % 3) || (((index + 1) % 3) && posts.length === index + 1)"
        :ref="`container-${(((index + 1) % 3) && posts.length === index + 1) ? 2 : index}`"
        v-show="clickedPostIndex === (posts.length < 3 ? 2 : index)"
      )
        post(:post="clickedPost" v-if="clickedPost")
</template>

<script>
import PostPreviewHeader from '@/components/postPreview/postPreviewHeader.vue';
import PostPreviewBody from '@/components/postPreview/postPreviewBody.vue';
import Post from '@/components/posts/post.vue';
import moment from 'moment';

export default {
  name: 'postPreview',
  components: { Post, PostPreviewBody, PostPreviewHeader },
  props: {
    posts: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      clickedPost: '',
      clickedPostIndex: '',
      moment,
    };
  },
  mounted() {
    this.$root.$on('postClicked', (post) => {
      let inPosts = false;
      this.posts.forEach((elem) => {
        if (elem.id !== post.id) {
          inPosts = true;
        }
      });
      if (!inPosts) {
        this.clickedPost = '';
      }
    });
  },
  methods: {
    showFullInfo(post, index) {
      this.clickedPost = post;
      this.clickedPostIndex = index + 2 - (index % 3);
    },
    sourceIcon(source) {
      if (source === 'vk') return 'icon-vk.svg';
      if (source === 'fb') return 'icon-fb.svg';
      if (source === 'gs') return 'icon-smi.svg';
      if (source === 'tw') return 'icon-tw.svg';
      return 'icon-stab.png';
    },
  },
};
</script>

<style lang="stylus">
.post-preview
  display flex
  cursor pointer
  margin  0 .4em 1em
  &:hover
    box-shadow 0 0 7px rgba(0,0,0,.15)
  &-container
    display flex
    flex-wrap wrap
    margin 0 0 1em 0
    padding-right 1em
.post-more-container
  background #fff
  padding 2em
  margin 1em .4em 2em
  border-radius 4px
.post-preview-row
  display flex
  align-items flex-start
  justify-content flex-start
  width 100%
  flex-wrap wrap
.post-preview
  width calc(33% - .6em)
  display flex
  flex-direction column
  cursor pointer
  margin  0 .4em 1em
  &:hover
    box-shadow 0 0 7px rgba(0,0,0,.15)
  &-container
    display flex
    flex-wrap wrap
    margin 0 0 1em 0
    padding-rigtht 1em
.post-more-container
  background #fff
  padding 2em
  margin 1em .4em 2em
  border-radius 4px
  width 100%
.post__date
  width 100%
  text-align right
  margin-top auto
  display flex
  align-items center
  justify-content flex-end
.post__source-icon
  margin-right .5em
</style>
