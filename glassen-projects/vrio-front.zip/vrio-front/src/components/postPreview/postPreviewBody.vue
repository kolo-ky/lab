<template lang="pug">
  .post-preview-body
    p.post-preview-body__content(
      ref="postContent"
      :class=""
      v-html="trimHref"
    )
</template>

<script>
export default {
  name: 'postPreviewBody',
  data() {
    return {
      trimTextLength: 300,
    };
  },
  props: {
    post: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  computed: {
    trimHref() {
      const textArr = this.trimmedText.split(' ');
      return textArr.map((elem) => {
        const elemHttpIndex = elem.indexOf('http://') + 1 || elem.indexOf('https://') + 1;
        if (elemHttpIndex) {
          const link = elem.slice(elemHttpIndex - 1).replace(/[а-яА-я\n\t\r]+/g, '');
          return `<a href="${link}" target="_blank">${elem.substring(0, 40)}...</a>`;
        }
        return elem;
      }).join(' ');
    },
    trimmedText() {
      if (this.trimTextLength > this.post.text) {
        return this.text;
      }
      return `${this.post.text.substring(0, this.trimTextLength)} ...`;
    },
  },
};
</script>

<style lang="stylus">
.post-preview
  &-body
    width 100%
    line-height 1.5em
    overflow hidden
    &__show-more
      cursor pointer
      font-weight bold
      color #460303
      margin 1em 0
</style>
