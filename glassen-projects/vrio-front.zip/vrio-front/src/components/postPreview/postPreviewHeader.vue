<template lang="pug">
  .post-header
    post-user-icon(:icon="post.author_logo")
    .post-preview-header__info
      .post-header__user-name.post-preview-header__user-name {{ post.author }}
      post-counters(:post="post")
</template>

<script>
import PostUserIcon from '@/components/posts/postUserIcon.vue';
import PostCounters from '@/components/posts/postCounters.vue';

export default {
  name: 'postPreviewHeader',
  components: { PostCounters, PostUserIcon },
  props: {
    post: {
      type: Object,
      default() {
        return {};
      },
    },
  },
};
</script>

<style lang="stylus">
.post
  width 100%
  &-header
    &__user-name
      margin 0 1em
      color #460303
    &__counters
      display flex
      align-items center
      margin-left auto
  &-counter
    display flex
    align-items center
    &__icon
      margin-left .8em
      height .8em
      width auto
    &__count
      margin-left .3em
.post-preview-header__user-name
  margin-bottom .3em
</style>
