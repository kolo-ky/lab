<template lang="pug">
  .post-preview-row
    .post-preview.main-container(
      @click="showFullPostAction"
    )
      post-preview-header
      post-preview-body
    .post-preview.main-container
      post-preview-header
      post-preview-body
    .post-preview.main-container
      post-preview-header
      post-preview-body
    .post-more-container(v-if="postForShow")
      post
</template>

<script>
import PostPreviewHeader from '@/components/postPreview/postPreviewHeader.vue';
import PostPreviewBody from '@/components/postPreview/postPreviewBody.vue';
import Post from '@/components/posts/post.vue';

export default {
  name: 'postPreviewRow',
  components: { Post, PostPreviewBody, PostPreviewHeader },
  data() {
    return {
      postForShow: '',
    };
  },
  methods: {
    showFullPostAction() {
      this.postForShow = 11;
    },
  },
};
</script>

<style lang="stylus">
.post-preview-row
  display flex
  align-items flex-start
  justify-content flex-start
  width 100%
  flex-wrap wrap
.post-preview
  width calc(33% - 1em)
  display flex
  flex-direction column
  cursor pointer
  margin  0 .4em 1em
  &:hover
    box-shadow 0 0 7px rgba(0,0,0,.15)
  &-container
    display flex
    flex-wrap wrap
    margin 0 0 1em 0
    padding-right 1em
.post-more-container
  background #fff
  padding 2em
  margin 1em .4em 2em
  border-radius 4px
</style>
