<template lang="pug">
  .post-comment
    img.post-comment__user-icon(
      :src="comment.author_logo"
    )
    .post-comment__body
      .post-comment__user-name {{ comment.author }}
      .post-comment__text(v-html="comment.text")
      .post-comment__date {{ moment(comment.created_date).format('HH:mm DD.MM.YYYY') }}
    <!--template(v-if="reComments.length > 2 && !showReComment")-->
      <!--.post-re-comment-prev(@click="showReComment = true")-->
        <!--img.post-re-comment-prev__user-icon(-->
          <!--src="https://pp.userapi.com/c849028/v849028949/ad24a/aiLITs-ybKI.jpg?ava=1"-->
        <!--)-->
        <!--.post-re-comment-prev__user-name Spiridon Robakidze-->
        <!--span &nbspответил. Всего&nbsp-->
        <!--.post-re-comment-prev__count  {{ reComments.length }}-->
        <!--span &nbsp{{ reComments.length < 5 ? 'ответа.' : 'ответов.'}}-->
    <!--template(v-if="reComments.length > 2 && showReComment")-->
      <!--post-re-comment(-->
        <!--v-for="reComment in reComments"-->
      <!--)-->
    <!--template(v-if="reComments.length <= 2")-->
      <!--post-re-comment(-->
        <!--v-for="reComment in reComments"-->
      <!--)-->
</template>

<script>
import PostReComment from '@/components/posts/postReComment.vue';
import moment from 'moment';

export default {
  name: 'postComment',
  components: { PostReComment },
  props: {
    comment: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  data() {
    return {
      showReComment: false,
      moment,
    };
  },
};
</script>

<style lang="stylus">
.post-comment
  display flex
  width 100%
  margin-top 1em
  &:not(:last-child) .post-comment__body
    border-bottom 1px solid #ccc
  &__user-icon
    width 2.5em
    height 2.5em
    border-radius 50%
    margin .5em 1em 0 0
    flex-shrink 0
  &__body
    flex-grow 1
    padding-bottom 1em
  &__user-name
    color #460303
    margin .3em 0
  &__date
    margin .3em 0
.post-re-comment-prev
  width 100%
  display flex
  align-items center
  margin-left 3.6em
  &:hover
    text-decoration underline
    cursor pointer
  &__user-icon
    width 2.2em
    height 2.2em
    border-radius 50%
    margin 1em 1em 1em 0
    flex-shrink 0
  &__user-name
    color #460303
  &__count
    font-weight bold
    color #460303
</style>
