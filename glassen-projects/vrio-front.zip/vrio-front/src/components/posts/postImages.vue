<template lang="pug">

</template>

<script>
export default {
  name: 'postImages',
};
</script>

<style lang="stylus">

</style>
