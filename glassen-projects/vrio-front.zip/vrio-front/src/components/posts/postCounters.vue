<template lang="pug">
  .post-header__counters
    .post-counter
      img.post-counter__icon(src="../../assets/images/seen-count-icon.svg")
      .post-counter__count {{ post.viewed }}
    .post-counter
      img.post-counter__icon(src="../../assets/images/icon-like.svg")
      .post-counter__count {{ post.likes }}
    .post-counter
      img.post-counter__icon(src="../../assets/images/icon-comment.svg")
      .post-counter__count {{ post.comments }}
    .post-counter
      img.post-counter__icon(src="../../assets/images/icon-repost.svg")
      .post-counter__count {{ post.reposts }}
</template>

<script>
export default {
  name: 'postCounters',
  props: {
    post: {
      type: Object,
      default() {
        return {};
      },
    },
  },
};
</script>

<style lang="stylus">
.post-counter
  display flex
  @media screen and (max-width 1100px)
    font-size .8em
  @media screen and (max-width 900px)
    flex-direction column
    margin-left .5em
  &__icon
    margin-left .8em
  &__count
    margin-left .3em
.post-header__counters
  display flex
  align-items center
  margin-left auto
</style>
