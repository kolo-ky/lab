<template lang="pug">

</template>

<script>
export default {
  name: 'postsFlatTemplate',
};
</script>

<style lang="stylus">

</style>
