<template lang="pug">
  img.post-header__user-icon(
    :src="icon"
  )
</template>

<script>
export default {
  name: 'postUserIcon',
  props: {
    icon: {
      type: String,
      default: '',
    },
  },
};
</script>

<style lang="stylus">
.post
  width 100%
  &-header
    display flex
    align-items center
    width 100%
    &__user-icon
      border-radius 50%
      width 4em
      height 4em
      flex-shrink 0
</style>
