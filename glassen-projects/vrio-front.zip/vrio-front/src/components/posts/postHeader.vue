<template lang="pug">
  .post-header
    post-user-icon(:icon="post.author_logo") {{ post.user }}
    .post-header__user-name {{ post.author }}
    post-counters(:post="post")
</template>

<script>
import PostCounters from '@/components/posts/postCounters.vue';
import PostUserIcon from '@/components/posts/postUserIcon.vue';

export default {
  name: 'postHeader',
  components: { PostUserIcon, PostCounters },
  props: {
    post: {
      type: Object,
      default() {
        return {};
      },
    },
  },
};
</script>

<style lang="stylus">
.post
  width 100%
  &-header
    &__user-name
      margin 0 1em
      color #460303
    &__counters
      display flex
      align-items center
      margin-left auto
  &-counter
    display flex
    &__icon
      margin-left .8em
      flex-shrink 0
    &__count
      margin-left .3em
</style>
