<template lang="pug">
  .posts(v-bar)
    div(@scroll="test" ref="top")
      show-menu-btn
      post-preview(:posts="postsFilteredByCheckboxType" v-if="items.length")
      table-preloader(v-if="reqPending" style="margin-top: 4em")
      scroll-top-button(@onScroll="handleScroll" v-if="position")
</template>

<script>
import Post from '@/components/posts/post.vue';
import PostPreview from '@/components/postPreview/postPreview.vue';
import { getPostsApi } from '@/api/posts';
import TablePreloader from '@/components/preLoaders/tablePreloader.vue';
import { SET_POSTS_COUNT } from '@/store/actions/threadInfo';
import ShowMenuBtn from '@/components/header/showMenuBtn.vue';
import ScrollTopButton from '@/components/ScrollTopButton.vue';

export default {
  name: 'posts',
  components: {
    ShowMenuBtn,
    TablePreloader,
    PostPreview,
    Post,
    ScrollTopButton,
  },
  data() {
    return {
      items: [],
      reqPending: false,
      count: '',
      start: 0,
      postRequestTimeout: '',
      position: 0,
    };
  },
  methods: {
    test($event) {
      const element = $event.target;

      this.updateContentScrollPosition(element);

      if (element.scrollHeight - element.scrollTop === element.clientHeight) {
        if (this.items.length + 1 < this.count) {
          this.getPosts(this.$route.params.id);
        }
      }
    },
    updateContentScrollPosition(element) {
      this.position = element.scrollTop;
    },
    handleScroll() {
      this.$refs.top.scrollTop = 0;
    },
    getPosts(id) {
      this.reqPending = true;
      const params = {
        thread_id: id,
        limit: 20,
        start: this.start,
        sort: {
          type: 'date',
          order: 'desc',
        },
      };
      this.postRequestTimeout = setTimeout(() => {
        this.$root.$emit('postRequestTimeout');
      }, 180000);
      getPostsApi(params)
        .then((req) => {
          this.items = this.items.concat(req.data.posts);
          this.reqPending = false;
          this.count = req.data.count;
          this.start += this.start;
          this.$store.dispatch(SET_POSTS_COUNT, this.count);
          this.$root.$emit('postsLoaded');
          clearTimeout(this.postRequestTimeout);
        });
    },
    getHeight() {
      const headerHeight = window.document.querySelector('.header').offsetHeight;
      document.querySelector('.wrapper').style.height = `${document.body.offsetHeight - headerHeight - document.querySelector('.work-area').style.marginTop - document.querySelector('.work-area').style.marginBottom}px`;
    },
  },
  computed: {
    postsFilteredByCheckboxType() {
      const types = this.$store.state.posts.postTypesToShow;
      if (types.length !== 2) {
        if (types[0] === 'soc') {
          return this.items.filter(post => post.network_name !== 'gs');
        } if (types[0] === 'smi') {
          return this.items.filter(post => post.network_name === 'gs');
        }
        return this.items;
      }
      return this.items;
    },
  },
  mounted() {
    this.items = [];
    this.count = '';
    this.getPosts(this.$route.params.id);
    // this.getHeight();
  },
  watch: {
    $route() {
      this.items = [];
      this.getPosts(this.$route.params.id);
    },
  },
};
</script>

<style lang="stylus">
.posts
  display flex
  flex-direction column
  overflow hidden
  padding-top 2em
  .post:last-child
    margin-bottom 0
</style>
