<template lang="pug">
  .post
    post-header(:post="post")
    post-body(:text="post.text")
    .post__date {{ post.created_date }}
    post-repost(:post="post.repost" v-if="Object.keys(post.repost).length")
    .post-comments(v-if="post.comments !== '0'")
      .post-comments-count
        img.post-comments-count__icon(src="../../assets/images/icon-comment.svg")
        span.post-comments-count__count {{ post.comments }}
        span.post-comments-count__show(
          @click="showCommentsAction"
        ) {{ showComments ? 'Скрыть' : 'Показать' }}
      template(v-if="showComments")
        post-comment(v-for="comment in commentaries" :comment="comment")
        <!--span.post-comments-count__show-more(-->
          <!--@click="showMoreComments = !showMoreComments"-->
        <!--) Показать еще-->
        span.post-comments-count__show(
          @click="showComments = !showComments"
        ) Скрыть
</template>

<script>
import PostHeader from '@/components/posts/postHeader.vue';
import PostBody from '@/components/posts/postBody.vue';
import PostComment from '@/components/posts/postComment.vue';
import PostRepost from '@/components/posts/postRepost.vue';
import PostReComment from '@/components/posts/postReComment.vue';
import { getCommentsApi } from '@/api/posts';

export default {
  name: 'post',
  components: {
    PostReComment,
    PostRepost,
    PostComment,
    PostBody,
    PostHeader,
  },
  props: {
    post: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  data() {
    return {
      showComments: false,
      showMoreComments: false,
      commentaries: '',
    };
  },
  methods: {
    showCommentsAction() {
      this.showComments = !this.showComments;
      const params = {
        limit: 30,
        network_id: this.post.network_id,
        owner_id: this.post.owner_id,
        post_id: this.post.id,
        start: 0,
        thread_id: this.$route.params.id,
      };
      getCommentsApi(params)
        .then((resp) => {
          this.commentaries = resp.data.commentaries;
        });
    },
  },
};
</script>

<style lang="stylus">
.post
  display flex
  flex-direction column
  &-comments
    border-top 1px solid #ccc
    width 100%
    margin-top 1em
    padding 1em 0
    &-count
      display flex
      align-items center
      cursor pointer
      margin-bottom 1em
      &__icon
        width 1.4em
        hieght 1.4em
        margin 0 1em 0 0
      &__show
        display inline-block
        margin-left 1em
        font-weight bold
        color #460303
        cursor pointer
      &__show-more
        display inline-block
        margin-left 1em
        font-weight bold
        color #460303
        cursor pointer
</style>
