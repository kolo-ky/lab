<template lang="pug">
  .post-comment.post-re-comment
    img.post-comment__user-icon(
      src="https://pp.userapi.com/c849028/v849028949/ad24a/aiLITs-ybKI.jpg?ava=1"
    )
    .post-comment__body
      .post-comment__user-name Spiridon Robakidze
      .post-comment__text(v-html="text")
</template>

<script>
import PostComment from '@/components/posts/postComment.vue';

export default {
  name: 'postReComment',
  components: { PostComment },
  data() {
    return {
      text: 'комментарий классный, как и я сам :)',
    };
  },
};
</script>

<style lang="stylus">
.post-re-comment
  margin-left 3em
  margin-top 1em
  padding-bottom 0
  &:first-child
    margin-top 1em
  .post-comment__user-icon
    width 2em
    height 2em
    margin-right .6em
    margin-left .6em
</style>
