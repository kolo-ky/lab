<template lang="pug">
  .post.post-repost
    post-header(:post="post")
    post-body(:text="post.text")
</template>

<script>
import PostHeader from '@/components/posts/postHeader.vue';
import PostBody from '@/components/posts/postBody.vue';
import Post from '@/components/posts/post.vue';

export default {
  name: 'postRepost',
  components: { Post, PostBody, PostHeader },
  props: {
    post: {
      type: Object,
      default() {
        return {};
      },
    },
  },
};
</script>

<style lang="stylus">
.post-repost
  padding 1em 0 0 1em
  border-left 3px solid #ccc
  & .post-header__user-icon
    width 3em
    height 3em
</style>
