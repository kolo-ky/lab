<template lang="pug">
  .post-body
    p.post-body__content(
      ref="postContent"
      v-html="trimmedText"
    )
    .post-body__show-more(
      v-if="trimTextLength < text.length"
      @click="trimText = !trimText"
    )
      | {{ trimText ? 'Подробнее' : 'Скрыть' }}
</template>

<script>
export default {
  name: 'postBody',
  props: {
    text: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      trimText: true,
      trimTextLength: 500,
    };
  },
  computed: {
    trimmedText() {
      if (!this.trimText && this.trimTextLength < this.text.length) {
        return this.text;
      }
      if (this.trimText && this.trimTextLength > this.text.length) {
        return this.text;
      }
      return `${this.text.substring(0, this.trimTextLength)} ...`;
    },
  },
};
</script>

<style lang="stylus">
.post
  &-body
    width 100%
    line-height 1.5em
    &__show-more
      cursor pointer
      font-weight bold
      color #460303
      margin 1em 0
</style>
