<template lang="pug">

</template>

<script>
export default {
  name: 'postAudio',
};
</script>

<style lang="stylus">

</style>
