<template lang="pug">

</template>

<script>
export default {
  name: 'postVideo',
};
</script>

<style lang="stylus">

</style>
