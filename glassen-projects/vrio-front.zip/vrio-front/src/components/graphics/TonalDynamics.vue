<template>
  <line-chart
    :chart-data="dataCollection"
    :options="options"
  ></line-chart>
</template>

<script>
import { LineChart } from '@/components/postsDynamicChart';

const MAIN_COLOR = '#000000';

export default {
  name: 'TonalDynamics',
  data() {
    return {
      dataCollection: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
          {
            label: 'Data One',
            borderColor: MAIN_COLOR,
            pointBackgroundColor: MAIN_COLOR,
            lineTension: 0,
            backgroundColor: 'transparent',
            data: [40, 39, 10, 40, 39, 80, 40],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
          display: false,
        },
        plugins: {
          datalabels: {
            display: false,
          },
        },
      },
    };
  },
  components: {
    LineChart,
  },
};
</script>
