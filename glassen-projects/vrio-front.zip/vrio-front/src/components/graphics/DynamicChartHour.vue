<template>
  <line-chart
    :chart-data="dataCollection"
    :options="options"
  ></line-chart>
</template>

<script>
import { LineChart } from '@/components/postsDynamicChart';

export default {
  name: 'DynamicChartHour',
  data() {
    return {
      dataCollection: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
          {
            label: 'Data One',
            borderColor: '#1400ff',
            pointBackgroundColor: '#1400ff',
            lineTension: 0,
            backgroundColor: 'transparent',
            data: [40, 39, 10, 40, 39, 80, 40],
          },
          {
            label: 'Data Two',
            borderColor: '#069df2',
            pointBackgroundColor: '#069df2',
            lineTension: 0,
            backgroundColor: 'transparent',
            data: [60, 55, 32, 10, 2, 12, 53],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
          display: false,
        },
        plugins: {
          datalabels: {
            display: false,
          },
        },
      },
    };
  },
  components: {
    LineChart,
  },
};
</script>
