<template lang="pug">
  nav.thread-nav(v-bar)
    div
      .thread-nav__inner(ref="threadNav")
        router-link(
          v-for="feed in feeds"
          v-if="feed.uid === '834'"
          :to="{ name: 'threadId', params: { threadName: feed.threadname, id: feed.id} }"
          :key="feed.id"
          active-class="thread-nav__link--current"
          :class="{'thread-nav__link--attention': feed.featured}"
        ).thread-nav__link {{ feed.threadname }}
</template>

<script>
import { getThreadsApi } from '@/api/posts';
import { SET_THREAD_NAME } from '@/store/actions/threadInfo';

//helpers
import { findIndexById } from '@/helpers/arrayHelper.js';

export default {
  name: 'threadsMainNav',
  props: {
    translationPlay: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      feeds: [],
      threadPlayTimeout: '',
    };
  },
  mounted() {
    this.getThreads();
  },
  updated() {
    this.$nextTick(() => {
      if (!this.$route.params.id) {
        this.$refs.threadNav.firstElementChild.click();
      }
    });
  },
  methods: {
    threadsAnimation() {
      const currentLink = this.$refs.threadNav.querySelector('.thread-nav__link--current');
      currentLink.classList.add('thread-nav__link--animate');
      setTimeout(() => {
        const promise = new Promise((resolve, reject) => {
          let index = findIndexById(this.feeds, this.$route.params.id);

          let readFeeds = this.feeds.slice(0, index + 1);
          this.feeds.splice(0, index + 1);
          this.feeds = [...this.feeds, ...readFeeds];

          resolve();
        });
        promise
          .then(() => {
            this.$refs.threadNav.querySelector('a').click();
          });
      }, 400);
    },
    getNavHeight() {
      const threadNav = this.$refs.threadNav;
      if (threadNav.querySelector('a')) {
        const style = window.getComputedStyle(threadNav.querySelector('a'));
        threadNav.style.height = `${(threadNav.querySelector('a').offsetHeight + Number(style.marginBottom.replace('px', ''))) * 6}px`;
      }
    },
    getThreads() {
      getThreadsApi()
        .then((resp) => {
          this.feeds = resp.data;
        });
    },
  },
  watch: {
    $route(val) {
      if (val.params.threadName) {
        this.$store.dispatch(SET_THREAD_NAME, this.$route.params.threadName);
      }
    },
    translationPlay(val) {
      if (val) {
        this.$refs.threadNav.children[0].click();
        this.threadPlayTimeout = setInterval(() => {
          this.threadsAnimation();
        }, 60000);
      } else {
        clearInterval(this.threadPlayTimeout);
      }
    },
  },
};
</script>

<style lang="stylus">
.thread-nav
  &__inner
    display flex
    flex-direction column
    height 310px
  &__link
    font-size 1.2em
    padding .8em 1em
    white-space nowrap
    background #dbdbdb
    color #3c3c3c
    border-radius 40px
    width 325px
    text-decoration none
    margin-bottom .9em
    overflow hidden
    flex-shrink 0
    transition .5s ease-in-out
    &:hover
      color #fff
      background #601b95
    &--attention
      background #ffc700
    &--current
      background #601b95
      color #fff
    &--animate
      position relative
      top -2.7em
      margin-bottom -2.7em
      opacity 0
      visibility hidden
</style>
