<template lang="pug">
  .left-side-bar(v-if="$route.name !== 'map'" ref="sideBar")
    .left-side-bar__close(@click="$root.$emit('showMainNavStateChange', false)")
      span
      span
    .translation-controls(ref="translationControls")
      user-menu
      div(@click="translationPlay = !translationPlay" class="switch-wrapper")
        translation-preloader(v-if="translationPlay")
        img(
          src="../../assets/images/play.svg"
          width="32px"
          height="32px"
          v-else
        )
      info-panel-checkboxes
    threads-main-nav(:translationPlay="translationPlay" ref="threadsNav")
    info-panel-counts
    posts-dynamic
    sidebar-controls(v-if="1>2")
</template>

<script>
import ThreadsMainNav from '@/components/navBars/threadsMainNav.vue';
import TranslationPreloader from '@/components/preLoaders/translationPreloader.vue';
import UserMenu from '@/components/header/userMenu.vue';
import InfoPanelCheckboxes from '@/components/infoPanel/infoPanelCheckboxes.vue';
import InfoPanelCounts from '@/components/infoPanel/infoPanelCounts.vue';
import PostsDynamic from '@/components/postsDynamic.vue';
import SidebarControls from '@/components/SidebarControls/Controls.vue';


export default {
  name: 'mainLeftSideBar',
  components: {
    PostsDynamic,
    InfoPanelCounts,
    InfoPanelCheckboxes,
    UserMenu,
    TranslationPreloader,
    ThreadsMainNav,
    SidebarControls,
  },
  data() {
    return {
      feedsType: [],
      translationPlay: false,
    };
  },
  mounted() {
    this.$root.$on('showMainNavStateChange', (state) => {
      if (state) {
        this.$refs.sideBar.classList.add('left-side-bar--visible');
      } else {
        this.$refs.sideBar.classList.remove('left-side-bar--visible');
      }
    });
    this.$root.$on('stopAutoPlay', () => {
      this.translationPlay = false;
    });
  },
};
</script>

<style lang="stylus">
.left-side-bar
  display flex
  flex-direction column
  overflow hidden
  margin 2em 0 0 0
  flex-shrink 0
  @media screen and (max-width 1100px)
    position absolute
    top -2em
    right 100%
    z-index 100
    background #fff
    padding 2em 3em 0 2em
    height 100vh
    transition .2s ease-in-out
    opacity 0
    visibility hidden
  &--visible
    opacity 1
    visibility visible
    transform translateX(100%)
  &__close
    width 2em
    height 2em
    position absolute
    right .5em
    top .5em
    cursor pointer
    display none
    @media screen and (max-width 1100px)
      display block
    span
      position absolute
      width 100%
      height 3px
      border-radius 4px
      background #601b95
      left 0
      top 50%
      transform translateY(-50%)
      transform-origin center
      &:nth-child(1)
        transform rotate(-45deg)
      &:nth-child(2)
        transform rotate(45deg)
.translation-controls
  display flex
  align-items center
  flex-shrink 0
  margin-bottom 2em
  padding-right 15px
  cursor pointer
  align-self flex-start
  width 100%
  &__start
    display flex
    align-items center
    background #fff
    border-radius 20px
    align-self stretch
    padding .8em 2em
    font-size 1.2em
    color #601b95
    margin-left auto
    cursor pointer
    margin-right 10px
    @media screen and (max-width 1100px)
      border 2px solid #601b95
    img
      margin-right 1em
</style>
