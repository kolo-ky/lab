<template>
  <ul class="sidebar-controls">
    <router-link
      tag="li"
      :to="`/reports/${$route.params.id}`"
      class="sidebar-controls__item"
      active-class="sidebar-controls__item--active"
    >
      Отчеты
    </router-link>
    <router-link
      tag="li"
      :to="`/picture-of-the-day/${$route.params.id}`"
      class="sidebar-controls__item"
      active-class="sidebar-controls__item--active"
    >
      Картина дня
    </router-link>
  </ul>
</template>

<script>
export default {
  name: 'Controls',
};
</script>

<style>
  .sidebar-controls {
    display: flex;
    justify-content: space-between;
    padding: 0;
    margin: 0;
    list-style: none;
  }

  .sidebar-controls__item {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 160px;
    height: 35px;
    font-weight: bold;
    line-height: 19px;
    font-size: 14px;
    color: #601B95;
    background-color: #fff;
    border-radius: 4px;
    box-sizing: border-box;
    cursor: pointer;
    transition: background-color, color;
    transition-duration: 0.4s, 0.4s;
  }

  .sidebar-controls__item--active,
  .sidebar-controls__item:hover {
    background-color: #601B95;
    color: #fff;
  }
</style>
