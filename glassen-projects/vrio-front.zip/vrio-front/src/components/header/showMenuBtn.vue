<template lang="pug">
  .left-side-bar__show-btn(@click="showMainNav")
    span
    span
    span
</template>

<script>
export default {
  name: 'showMenuBtn',
  methods: {
    showMainNav() {
      this.$root.$emit('showMainNavStateChange', true);
    },
  },
};
</script>

<style lang="stylus">
.left-side-bar__show-btn
  position absolute
  left 0
  top 1em
  width 3em
  height 2em
  margin 0 2em 0 .4em
  cursor pointer
  display none
  @media screen and (max-width 1100px)
    display block
  span
    position absolute
    left 0
    width 100%
    height 4px
    border-radius 4px
    background #601b95
    &:nth-child(1)
      top 0
    &:nth-child(2)
      top 50%
      transform translate(0, -50%)
    &:nth-child(3)
      bottom 0
</style>
