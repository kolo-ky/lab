<template lang="pug">
  .header-user(@click="showMenu = !showMenu")
    img.header-user__icon(
      src="../../assets/images/icon-user.png"
    )
    .header-user__menu(v-if="showMenu")
      .header-user__item(@click="logout") Выход
</template>

<script>
import { AUTH_LOGOUT } from '@/store/actions/auth';

export default {
  name: 'userMenu',
  data() {
    return {
      showMenu: false,
    };
  },
  methods: {
    logout() {
      this.$store.dispatch(AUTH_LOGOUT);
    },
  },
};
</script>

<style lang="stylus">
.header
  margin-bottom 2.2em
  &-user
    position relative
    height 3em
    width 3em
    background #c4c4c4
    flex-shrink 0
    border-radius 50%
    cursor pointer
    display flex
    align-items center
    justify-content center
    margin 0 1em 0 0
    &__menu
      position absolute
      width auto
      white-space nowrap
      left 0
      top calc(100%)
      padding 0.2em 0
      border 1px solid #3a3a3a
      border-radius 4px
      background #fff
      z-index 20
    &__item
      padding 0.8em 1.2em
      &:hover
        background #e1e5eb
</style>
