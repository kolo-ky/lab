<template lang="pug">
  .header-nav__outer
    .header-nav__arrow.header-nav__arrow--left(v-if="showArrows" @click="scrollLeft")
    .header-nav__arrow.header-nav__arrow--right(v-if="showArrows" @click="scrollRight")
    nav.header-nav(ref="mainNav")
      router-link(
        v-for="item in items"
        v-if="item.uid === '834'"
        :to="`/thread-id-${item.id}`"
        active-class="header-nav__link--current"
      ).header-nav__link {{ item.threadname }}
</template>

<script>
export default {
  name: 'headerNav',
  data() {
    return {
      showArrows: false,
    };
  },
  props: {
    items: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  mounted() {
    this.$nextTick(this.showArrowsState());
  },
  methods: {
    showArrowsState() {
      const elements = this.$refs.mainNav.querySelectorAll('.header-nav__link');
      let elementsSumWidth = 0;
      elements.forEach((elem) => {
        elementsSumWidth += elem.offsetWidth;
      });
      this.showArrows = this.$refs.mainNav.offsetWidth < elementsSumWidth;
    },
    scrollLeft() {
      this.$refs.mainNav.scrollLeft += -200;
    },
    scrollRight() {
      this.$refs.mainNav.scrollLeft += 200;
    },
  },
  updated() {
    this.$nextTick(this.showArrowsState());
  },
};
</script>

<style lang="stylus">
.header
  &-nav
    flex-grow 1
    display flex
    overflow hidden
    &__outer
      display flex
      align-items center
      white-space nowrap
      padding 0 3em
      position relative
      overflow hidden
      margin-right 2em
    &__arrow
      display block
      position absolute
      top 0
      transform-origin top left
      width 3em
      height 100%
      cursor pointer
      background #3a3a3a
      z-index 10
      &:after
        content ''
        position absolute
        display block
        width 1em
        height 1em
        top 50%
      &--left
        left 0
        &:after
          left 1em
          border-top 2px solid #fff
          border-left 2px solid #fff
          transform-origin left top
          transform rotate(-45deg)
      &--right
        right 0
        &:after
          right 1em
          border-top 2px solid #fff
          border-right 2px solid #fff
          transform-origin right top
          transform rotate(45deg)
    &__link
      color #fff
      text-decoration none
      padding .5em .8em
      margin-right 1em
      opacity .5
      border 1px solid #fff
      border-radius 4px
      transition .2s ease-in-out
      &:hover
        opacity 1
      &--current
        opacity 1
</style>
