<template lang="pug">
  .header-manager
    .header-manager__current Manager 1
    .header-manager__select
      .header-manager__item Manager 1
      .header-manager__item Manager 2
      .header-manager__item Manager 3
      .header-manager__item Manager 4
      .header-manager__item Manager 5
</template>

<script>
export default {
  name: 'managerSelect',
};
</script>

<style lang="stylus">
.header
  &-manager
    position relative
    cursor pointer
    padding 1em
    flex-shrink 0
    flex-basis calc((100% + 2em) * .15)
    margin-right 2em
    align-self stretch
    display flex
    align-items center
    margin-left -1em
    &__current
      color #fff
      width 100%
      max-width 100%
    &__select
      display none
      position absolute
</style>
