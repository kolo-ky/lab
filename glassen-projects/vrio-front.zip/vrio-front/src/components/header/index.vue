<template lang="pug">
  header.header
    .header__inner
      .header__ttl {{ $store.state.threadInfo.threadName }}
      user-menu
</template>

<script>
import HeaderNav from '@/components/header/headerNav.vue';
import ManagerSelect from '@/components/header/managerSelect.vue';
import UserMenu from '@/components/header/userMenu.vue';

export default {
  name: 'headerMain',
  components: { UserMenu, ManagerSelect, HeaderNav },
  data() {
    return {
      feeds: [],
      feedsSearch: '',
    };
  },
  methods: {
    showMainNav() {
      this.$root.$emit('showMainNavStateChange', true);
    },
  },
};
</script>

<style lang="stylus">
.header
  width 100%
  position relative
  margin-top 2em
  &__inner
    margin 0 auto
    display flex
    align-items center
    max-width 1440px
  &__ttl
    font-size 1.8em
    margin-left .2em
</style>
