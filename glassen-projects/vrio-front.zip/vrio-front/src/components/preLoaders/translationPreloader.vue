<template lang="pug">
  div.lds-ripple
</template>

<script>
export default {
  name: 'translationPreloader',
};
</script>

<style>
.lds-ripple {
  position: relative;
  margin-top: -2px;
  width: 32px;
  height: 32px;
  background-image: url("../../assets/images/stop.svg");
  background-size: 32px 32px;
  background-position: center center;
}
</style>
