<template>
  <button class="slide-top-button" @click="$emit('onScroll')"></button>
</template>

<script>
export default {
  name: 'ScrollTopButton',
};
</script>

<style>
  .slide-top-button {
    position: absolute;
    right: 50px;
    bottom: 50px;
    padding-top: 15px;
    width: 80px;
    height: 80px;
    border-radius: 50%;
    box-shadow: 0 0 10px rgba(0, 0, 0, .5);
    cursor: pointer;
    outline: none;
    box-sizing: border-box;
    opacity: 0.5;
    transition: opacity 0.3s;
  }

  .slide-top-button::before,
  .slide-top-button::after {
    display: block;
    margin: -15px auto;
    width: 20px;
    height: 20px;
    border-top: 2px solid #601b95;
    border-right: 2px solid #601b95;
    transform: rotate(-45deg);
    content: '';
  }

  .slide-top-button:hover {
    opacity: 1;
  }
</style>
