/* eslint no-shadow: ["error", { "allow": ["state"] }] */

import { POST_TYPE_TO_SHOW } from '@/store/actions/posts';

const state = {
  postTypesToShow: '',
};

const getters = {};

const actions = {
  [POST_TYPE_TO_SHOW]: ({ commit }, types) => {
    commit(POST_TYPE_TO_SHOW, types);
  },
};

const mutations = {
  [POST_TYPE_TO_SHOW]: (state, types) => {
    state.postTypesToShow = types;
  },
};

export default {
  state,
  getters,
  actions,
  mutations,
};
