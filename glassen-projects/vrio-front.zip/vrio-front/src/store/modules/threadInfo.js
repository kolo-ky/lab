/* eslint no-shadow: ["error", { "allow": ["state"] }] */

import { SET_POSTS_COUNT, SET_THREAD_NAME } from '@/store/actions/threadInfo';

const state = {
  threadFeedsCount: '',
  threadName: localStorage.getItem('threadName') || '',
};

const getters = {};

const actions = {
  [SET_POSTS_COUNT]: ({ commit }, count) => {
    commit(SET_POSTS_COUNT, count);
  },
  [SET_THREAD_NAME]: ({ commit }, name) => {
    commit(SET_THREAD_NAME, name);
  },
};

const mutations = {
  [SET_POSTS_COUNT]: (state, count) => {
    state.threadFeedsCount = count;
  },
  [SET_THREAD_NAME]: (state, name) => {
    state.threadName = name;
    localStorage.setItem('threadName', name);
  },
};

export default {
  state,
  getters,
  actions,
  mutations,
};
