/* eslint no-shadow: ["error", { "allow": ["state"] }] */

import router from '@/router';
import {
  AUTH_REQUEST,
  AUTH_SUCCESS,
  AUTH_ERROR,
  AUTH_LOGOUT,
  CHECK_SUCCESS,
} from '@/store/actions/auth';
import { login, logout } from '@/api/auth';

const state = {
  status: localStorage.getItem('status') || '',
};

const getters = {
  isAuthenticated: state => (state.status === 'success' || state.status === 'loading'),
};

const actions = {
  /**
   * @param commit
   * @param loginParams
   * @returns {Promise}
   */
  [AUTH_REQUEST]: ({ commit, dispatch }, loginParams) => new Promise((resolve, reject) => {
    commit(AUTH_REQUEST);
    login(loginParams)
      .then((resp) => {
        // const userId = resp.data.userSettings.id;
        // const userRole = resp.data.userSettings.role;
        commit(AUTH_SUCCESS);
        // dispatch(SET_USER_ID, userId);
        // dispatch(SET_USER_ROLE, userRole);
        resolve(resp);
      })
      .catch((err) => {
        commit(AUTH_ERROR, err);
        reject(err);
      });
  }),
  /**
   * @param commit
   * @param resetVal
   * @returns {Promise}
   */
  [AUTH_LOGOUT]: ({ commit }) => new Promise((resolve) => {
    commit(AUTH_REQUEST);
    logout()
      .then(() => {
        commit(AUTH_LOGOUT);
        router.push('/login');
        resolve();
      })
      .catch(() => {
        commit(AUTH_LOGOUT);
        router.push('/login');
        resolve();
      });
  }),
};

const mutations = {
  [AUTH_REQUEST]: (state) => {
    state.status = 'loading';
    localStorage.setItem('status', 'loading');
  },
  [AUTH_SUCCESS]: (state) => {
    state.status = 'success';
    localStorage.setItem('status', 'success');
  },
  [AUTH_ERROR]: (state) => {
    state.status = 'error';
    localStorage.removeItem('status');
  },
  [AUTH_LOGOUT]: (state) => {
    state.status = 'logout';
    localStorage.removeItem('status');
  },
  [CHECK_SUCCESS]: (state) => {
    state.status = 'success';
    localStorage.removeItem('status');
  },
};

export default {
  state,
  getters,
  actions,
  mutations,
};
