import Vue from 'vue';
import Vuex from 'vuex';
import auth from './modules/auth';
import threadInfo from './modules/threadInfo';
import posts from './modules/posts';

Vue.use(Vuex);

const debug = process.env.NODE_ENV !== 'production';

const store = new Vuex.Store({
  modules: {
    auth,
    threadInfo,
    posts,
  },
  strict: debug,
});

export default store;
