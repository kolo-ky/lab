import axios from '../axios/axios';

export function login(loginParams) {
  return axios.post('/authorization/login', loginParams);
}

export function logout() {
  return axios.post('/authorization/logout', {});
}

export function authCheck() {
  return axios.post('/authorization/logout', {});
}
