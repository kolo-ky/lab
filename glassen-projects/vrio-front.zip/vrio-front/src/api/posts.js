import axios from '../axios/axios';

export function getThreadsApi() {
  return axios.post('/threads/get', {});
}

export function getPostsApi(params) {
  return axios.post('/content/posts', params);
}

export function getCommentsApi(params) {
  return axios.post('/content/commentaries', params);
}

export function getWeekTrustApi(params) {
  return axios.post('/content/getweektrust', params);
}

export function getAdditionalInfoApi(params) {
  return axios.post('/thread/additional_info', params);
}
