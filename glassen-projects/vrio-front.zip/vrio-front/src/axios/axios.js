import axios from 'axios';

const API_URL = 'http://api.glassen-it.com/component/socparser';

export default axios.create({
  baseURL: API_URL,
  headers: {
    accept: '*/*',
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
  },
  withCredentials: true,
});
