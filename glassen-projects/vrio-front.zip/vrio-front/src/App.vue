<template lang="pug">
  #app
    .overlay(v-if="showOverlay" @click="$root.$emit('showMainNavStateChange', false)")
    .wrapper
      main-left-side-bar(v-if="$route.name !== 'login' && $route.name !== 'test'")
      router-view
</template>

<script>
import headerMain from '@/components/header/index.vue';
import MainLeftSideBar from '@/components/mainLeftSideBar/index.vue';


export default {
  components: { MainLeftSideBar, headerMain },
  data() {
    return {
      showOverlay: false,
    };
  },
  mounted() {
    this.$root.$on('showMainNavStateChange', (state) => {
      this.showOverlay = state;
    });
  },
};
</script>

<style lang="stylus">
@import "~normalize.css"
@import url('https://fonts.googleapis.com/css?family=Roboto');

*
  box-sizing border-box
body
  font-family Roboto
  font-size 12px
  background #e5e5e5
#app
  display flex
  flex-direction column
  height 100vh
.overlay
  position absolute
  width 100%
  height 100%
  background rgba(0,0,0,.4)
  z-index 50
.wrapper
  max-width 1440px
  margin 0 auto
  display flex
  flex-grow 1
  height 100vh
  width 100%
  padding 0 2.5em
  @media screen and (max-width: 1050px)
    padding 0 1em
.work-area
  flex-grow 1
  display flex
  flex-direction column
  margin-left 1.5em
  @media screen and (max-width: 1050px)
    margin-left 1em
.main-container
  width 100%
  display flex
  align-items center
  background #fff
  border-radius 4px
  padding 1em 1.5em
  margin-bottom 1em
  flex-shrink 0
//scroll
.vb > .vb-dragger {
    z-index: 5;
    width: 12px;
    right: 0;
}

.vb > .vb-dragger > .vb-dragger-styler {
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    -webkit-transform: rotate3d(0,0,0,0);
    transform: rotate3d(0,0,0,0);
    -webkit-transition:
        background-color 100ms ease-out,
        margin 100ms ease-out,
        height 100ms ease-out;
    transition:
        background-color 100ms ease-out,
        margin 100ms ease-out,
        height 100ms ease-out;
    background-color: rgba(58, 58, 58,.1);
    margin: 5px 5px 5px 0;
    border-radius: 20px;
    height: calc(100% - 10px);
    display: block;
}

.vb.vb-scrolling-phantom > .vb-dragger > .vb-dragger-styler {
    background-color: rgba(58, 58, 58,.3);
}

.vb > .vb-dragger:hover > .vb-dragger-styler {
    background-color: rgba(58, 58, 58,.5);
    margin: 0;
    height: 100%;
}

.vb.vb-dragging > .vb-dragger > .vb-dragger-styler {
    background-color: rgba(58, 58, 58,.5);
    margin: 0;
    height: 100%;
}

.vb.vb-dragging-phantom > .vb-dragger > .vb-dragger-styler {
    background-color: rgba(58, 58, 58,.5);
}
</style>
