import Vue from 'vue';
import Router from 'vue-router';
import store from '@/store/index';

Vue.use(Router);

const ifNotAuthenticated = (to, from, next) => {
  if (!store.getters.isAuthenticated) {
    next();
    return;
  }
  next('/');
};

const ifAuthenticated = (to, from, next) => {
  if (store.getters.isAuthenticated) {
    next();
    return;
  }
  if (!store.getters.isAuthenticated) {
    next('/login');
  }
};

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('@/views/Home'),
      beforeEnter: ifAuthenticated,
      children: [
        {
          path: '/thread-id-:id',
          component: () => import('@/views/Home'),
          name: 'threadId',
          props: true,
        },
      ],
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/Login'),
      beforeEnter: ifNotAuthenticated,
    },
    {
      path: '/map',
      name: 'map',
      component: () => import('@/views/Map'),
      beforeEnter: ifAuthenticated,
      children: [
        {
          path: 'thread-id-:id',
          component: () => import('@/views/Home'),
          name: 'map',
        },
      ],
    },
    {
      path: '/reports/:id',
      name: 'reports',
      component: () => import('@/views/Reports'),
      beforeEnter: ifAuthenticated,
    },
    {
      path: '/picture-of-the-day/:id',
      name: 'picture',
      component: () => import('@/views/Picture'),
      beforeEnter: ifAuthenticated,
    },
  ],
});
