export const findIndexById = (feeds, id) => {
  let index = 0;

  feeds.forEach((item, feedIndex) => {
    if(item.id === id) {
      index = feedIndex;
    }
  });

  return index;
};
